import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Github, Instagram, Linkedin, Menu, X, Phone, Users, Target, Play, BarChart3, Mic, ChevronRight, Check, ArrowLeft, ArrowRight, Zap, Clock, Shield } from 'lucide-react';
import { create } from 'zustand';

// Store for navigation and modal state
const useAppStore = create((set) => ({
  currentSection: 'home',
  isModalOpen: false,
  modalContent: null,
  formData: {},
  setCurrentSection: (section) => set({ currentSection: section }),
  openModal: (content) => set({ isModalOpen: true, modalContent: content }),
  closeModal: () => set({ isModalOpen: false, modalContent: null }),
  updateFormData: (data) => set((state) => ({ formData: { ...state.formData, ...data } })),
}));

// Modal Component
const Modal = ({ children, onClose }) => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
    >
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose} />
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="relative bg-gray-900 rounded-xl p-6 max-w-lg w-full border border-gray-700"
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors"
        >
          <X size={20} />
        </button>
        {children}
      </motion.div>
    </motion.div>
  );
};

// Feature Demo Modal Content
const FeatureDemoModal = ({ feature }) => {
  return (
    <div className="text-center">
      <div className="mb-4">
        {feature.icon}
      </div>
      <h3 className="text-white font-semibold text-xl mb-3">{feature.title}</h3>
      <p className="text-gray-300 mb-4">{feature.description}</p>
      <div className="bg-gray-800 rounded-lg p-4 mb-4">
        <div className="text-sm text-gray-400 mb-2">Demo Preview:</div>
        <div className="bg-gray-700 rounded h-32 flex items-center justify-center">
          <Play className="w-8 h-8 text-blue-400" />
        </div>
      </div>
      <button className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg transition-colors">
        Try Full Demo
      </button>
    </div>
  );
};

// Multi-step Contact Form
const ContactForm = () => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    company: '', size: '', country: '',
    name: '', email: '', role: '',
    interests: [], timeline: ''
  });
  const { closeModal } = useAppStore();

  const handleSubmit = () => {
    console.log('Form submitted:', formData);
    closeModal();
  };

  const renderStep = () => {
    switch(step) {
      case 1:
        return (
          <div>
            <h3 className="text-white font-semibold text-xl mb-4">Company Information</h3>
            <div className="space-y-4">
              <input
                type="text"
                placeholder="Company name"
                value={formData.company}
                onChange={(e) => setFormData({...formData, company: e.target.value})}
                className="w-full px-4 py-3 rounded-lg bg-gray-800 border border-gray-600 text-white focus:border-blue-400 outline-none"
              />
              <select
                value={formData.size}
                onChange={(e) => setFormData({...formData, size: e.target.value})}
                className="w-full px-4 py-3 rounded-lg bg-gray-800 border border-gray-600 text-white focus:border-blue-400 outline-none"
              >
                <option value="">Company size</option>
                <option value="<10">Less than 10</option>
                <option value="10-50">10-50 employees</option>
                <option value="50+">50+ employees</option>
              </select>
              <input
                type="text"
                placeholder="Country"
                value={formData.country}
                onChange={(e) => setFormData({...formData, country: e.target.value})}
                className="w-full px-4 py-3 rounded-lg bg-gray-800 border border-gray-600 text-white focus:border-blue-400 outline-none"
              />
            </div>
            <button
              onClick={() => setStep(2)}
              disabled={!formData.company || !formData.size}
              className="w-full mt-6 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 text-white py-3 rounded-lg transition-colors flex items-center justify-center"
            >
              Next <ArrowRight size={16} className="ml-2" />
            </button>
          </div>
        );
      case 2:
        return (
          <div>
            <h3 className="text-white font-semibold text-xl mb-4">Contact Person</h3>
            <div className="space-y-4">
              <input
                type="text"
                placeholder="Full name"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                className="w-full px-4 py-3 rounded-lg bg-gray-800 border border-gray-600 text-white focus:border-blue-400 outline-none"
              />
              <input
                type="email"
                placeholder="Email"
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
                className="w-full px-4 py-3 rounded-lg bg-gray-800 border border-gray-600 text-white focus:border-blue-400 outline-none"
              />
              <select
                value={formData.role}
                onChange={(e) => setFormData({...formData, role: e.target.value})}
                className="w-full px-4 py-3 rounded-lg bg-gray-800 border border-gray-600 text-white focus:border-blue-400 outline-none"
              >
                <option value="">Your role</option>
                <option value="manager">Manager</option>
                <option value="hr">HR</option>
                <option value="ceo">CEO</option>
                <option value="other">Other</option>
              </select>
            </div>
            <div className="flex gap-3 mt-6">
              <button
                onClick={() => setStep(1)}
                className="flex-1 bg-gray-700 hover:bg-gray-600 text-white py-3 rounded-lg transition-colors flex items-center justify-center"
              >
                <ArrowLeft size={16} className="mr-2" /> Back
              </button>
              <button
                onClick={() => setStep(3)}
                disabled={!formData.name || !formData.email}
                className="flex-1 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 text-white py-3 rounded-lg transition-colors flex items-center justify-center"
              >
                Next <ArrowRight size={16} className="ml-2" />
              </button>
            </div>
          </div>
        );
      case 3:
        return (
          <div>
            <h3 className="text-white font-semibold text-xl mb-4">Interest & Use Case</h3>
            <div className="space-y-4">
              <div>
                <p className="text-gray-300 mb-3">What are you most interested in?</p>
                <div className="space-y-2">
                  {['AI Interviews', 'Agent Training', 'Both'].map(interest => (
                    <label key={interest} className="flex items-center">
                      <input
                        type="checkbox"
                        checked={formData.interests.includes(interest)}
                        onChange={(e) => {
                          const interests = e.target.checked 
                            ? [...formData.interests, interest]
                            : formData.interests.filter(i => i !== interest);
                          setFormData({...formData, interests});
                        }}
                        className="mr-3"
                      />
                      <span className="text-white">{interest}</span>
                    </label>
                  ))}
                </div>
              </div>
              <select
                value={formData.timeline}
                onChange={(e) => setFormData({...formData, timeline: e.target.value})}
                className="w-full px-4 py-3 rounded-lg bg-gray-800 border border-gray-600 text-white focus:border-blue-400 outline-none"
              >
                <option value="">How soon would you like to start?</option>
                <option value="immediately">Immediately</option>
                <option value="this-month">This Month</option>
                <option value="later">Later</option>
              </select>
            </div>
            <div className="flex gap-3 mt-6">
              <button
                onClick={() => setStep(2)}
                className="flex-1 bg-gray-700 hover:bg-gray-600 text-white py-3 rounded-lg transition-colors flex items-center justify-center"
              >
                <ArrowLeft size={16} className="mr-2" /> Back
              </button>
              <button
                onClick={handleSubmit}
                disabled={formData.interests.length === 0 || !formData.timeline}
                className="flex-1 bg-green-600 hover:bg-green-700 disabled:bg-gray-600 text-white py-3 rounded-lg transition-colors flex items-center justify-center"
              >
                <Check size={16} className="mr-2" /> Submit
              </button>
            </div>
          </div>
        );
    }
  };

  return (
    <div>
      <div className="flex mb-6">
        {[1,2,3].map(i => (
          <div key={i} className={`flex-1 h-2 rounded-full mx-1 ${i <= step ? 'bg-blue-600' : 'bg-gray-700'}`} />
        ))}
      </div>
      {renderStep()}
    </div>
  );
};

// Home Section
const HomeSection = () => {
  const { openModal } = useAppStore();
  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const features = [
    {
      icon: <Mic className="w-8 h-8 text-blue-400" />,
      title: "AI Voice Interviews",
      description: "Pre-qualify candidates with intelligent AI-conducted interviews that assess communication skills and job fit."
    },
    {
      icon: <Users className="w-8 h-8 text-green-400" />,
      title: "Agent Training",
      description: "Level-based skill development for sales, support, and retention with personalized AI coaching."
    },
    {
      icon: <Target className="w-8 h-8 text-purple-400" />,
      title: "Smart Scorecards",
      description: "Receive detailed summaries and scores to make data-driven hiring decisions."
    }
  ];

  const handleEmailSubmit = (e) => {
    e.preventDefault();
    if (!email || !email.includes('@')) return;
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
      setEmail('');
      openModal(
        <div className="text-center">
          <div className="mb-4">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto">
              <Check className="w-8 h-8 text-green-600" />
            </div>
          </div>
          <h3 className="text-white font-semibold text-xl mb-3">Thanks! You're on the early list</h3>
          <p className="text-gray-300 mb-6">Want to test it for your company?</p>
          <button
            onClick={() => openModal(<ContactForm />)}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg transition-colors"
          >
            Book a Demo
          </button>
        </div>
      );
      setTimeout(() => setIsSubmitted(false), 3000);
    }, 1500);
  };

  return (
    <div className="text-center w-full max-w-6xl mx-auto flex flex-col items-center justify-center min-h-screen py-8 sm:py-16">
      <div className="mb-6 sm:mb-8">
        <div className="inline-flex items-center space-x-3 bg-gray-900/60 backdrop-blur-sm rounded-full py-2 px-3 sm:py-2 sm:px-4 text-xs sm:text-sm">
          <div className="flex -space-x-2 sm:-space-x-3">
            {[
              "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face",
              "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=100&h=100&fit=crop&crop=face",
              "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face",
              "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=100&h=100&fit=crop&crop=face"
            ].map((avatar, index) => (
              <div key={index} className="relative h-6 w-6 sm:h-8 sm:w-8 md:h-10 md:w-10 rounded-full overflow-hidden border-2 border-gray-700 shadow-lg">
                <img src={avatar} alt="User avatar" className="h-full w-full object-cover" />
              </div>
            ))}
          </div>
          <p className="text-white whitespace-nowrap">
            <span className="text-white font-semibold">1.2K+</span> managers already joined
          </p>
        </div>
      </div>

      <h1 className="w-full text-white leading-tight tracking-tight mb-6 sm:mb-8 px-4">
        <span className="block font-bold text-[clamp(2rem,8vw,4rem)] mb-2">
          Transform Your Call Center
        </span>
        <span className="block font-light text-[clamp(1.8rem,6vw,3rem)] text-blue-400">
          With AI-Powered Hiring & Training
        </span>
      </h1>

      <div className="mb-8 sm:mb-10 px-4 max-w-3xl">
        <p className="text-[clamp(1.1rem,3vw,1.4rem)] text-gray-300 leading-relaxed mb-4">
          Pre-qualify candidates through intelligent voice interviews and train your agents 
          with level-based skill development programs.
        </p>
      </div>

      <div className="w-full max-w-2xl mb-8 sm:mb-12 px-4">
        {!isSubmitted ? (
          <form onSubmit={handleEmailSubmit} className="flex flex-col sm:flex-row gap-3">
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email for early access"
              className="flex-1 px-6 sm:px-8 py-3 sm:py-4 rounded-full bg-gray-900/60 border border-gray-700 focus:border-white outline-none text-white text-sm sm:text-base shadow-[0_0_15px_rgba(0,0,0,0.3)] backdrop-blur-sm transition-all duration-300"
              required
            />
            <button
              type="submit"
              disabled={isSubmitting}
              className={`px-6 sm:px-8 py-3 sm:py-4 rounded-full transition-all duration-300 transform hover:scale-105 whitespace-nowrap text-sm sm:text-base ${
                isSubmitting
                  ? 'bg-gray-600 text-gray-300 cursor-not-allowed'
                  : 'bg-blue-600 hover:bg-blue-700 text-white'
              }`}
            >
              {isSubmitting ? (
                <div className="h-4 w-4 sm:h-5 sm:w-5 border-2 border-gray-300 border-t-white rounded-full animate-spin"></div>
              ) : (
                'Get Early Access'
              )}
            </button>
          </form>
        ) : (
          <div className="bg-green-500/20 border border-green-500/30 text-green-300 rounded-full px-6 sm:px-8 py-3 sm:py-4 text-center text-sm sm:text-base">
            Thanks! We'll notify you when we launch.
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 px-4">
        {features.map((feature, index) => (
          <motion.div
            key={index}
            whileHover={{ scale: 1.03, y: -5 }}
            className="bg-gray-900/40 backdrop-blur-sm border border-gray-700 rounded-xl p-6 text-center cursor-pointer"
            onClick={() => openModal(<FeatureDemoModal feature={feature} />)}
          >
            <div className="flex justify-center mb-4">
              {feature.icon}
            </div>
            <h3 className="text-white font-semibold text-lg mb-2">{feature.title}</h3>
            <p className="text-gray-400 text-sm">{feature.description}</p>
            <div className="mt-4 text-blue-400 text-sm flex items-center justify-center">
              View Demo <ChevronRight size={16} className="ml-1" />
            </div>
          </motion.div>
        ))}
      </div>

      <div className="flex justify-center space-x-6 mt-12">
        <a href="#" className="text-gray-500 hover:text-gray-300 transition-colors duration-300">
          <Instagram size={22} />
        </a>
        <a href="#" className="text-gray-500 hover:text-gray-300 transition-colors duration-300">
          <Linkedin size={22} />
        </a>
        <a href="#" className="text-gray-500 hover:text-gray-300 transition-colors duration-300">
          <Github size={22} />
        </a>
      </div>
    </div>
  );
};

// Features Section
const FeaturesSection = () => {
  const { openModal } = useAppStore();
  const [hoveredFeature, setHoveredFeature] = useState(null);

  const features = [
    {
      id: 'voice',
      icon: <Mic className="w-12 h-12 text-blue-400" />,
      title: "AI Voice Interviews",
      description: "Automated candidate screening with natural conversation flow",
      animation: "waveform",
      demo: "voice-interview"
    },
    {
      id: 'training',
      icon: <Users className="w-12 h-12 text-green-400" />,
      title: "Agent Training",
      description: "Level-based skill development with real-time feedback",
      animation: "progress",
      demo: "training-module"
    },
    {
      id: 'scorecards',
      icon: <BarChart3 className="w-12 h-12 text-purple-400" />,
      title: "Smart Scorecards",
      description: "AI-generated comprehensive candidate evaluation reports",
      animation: "chart",
      demo: "scorecard-sample"
    }
  ];

  const renderAnimation = (type, isHovered) => {
    switch (type) {
      case 'waveform':
        return (
          <div className="h-20 flex items-center justify-center space-x-1">
            {Array.from({ length: 8 }).map((_, i) => (
              <motion.div
                key={i}
                className="w-2 bg-blue-400 rounded-full"
                animate={isHovered ? {
                  height: [10, 30, 15, 40, 20, 35, 15, 25],
                  transition: { duration: 1, repeat: Infinity, delay: i * 0.1 }
                } : { height: 10 }}
              />
            ))}
          </div>
        );
      case 'progress':
        return (
          <div className="h-20 flex flex-col justify-center space-y-2 px-6">
            {['Sales', 'Support', 'Retention'].map((skill, i) => (
              <div key={skill} className="flex items-center space-x-3">
                <span className="text-xs text-gray-400 w-16">{skill}</span>
                <div className="flex-1 bg-gray-700 rounded-full h-2">
                  <motion.div
                    className="h-2 bg-green-400 rounded-full"
                    animate={isHovered ? { width: `${60 + i * 15}%` } : { width: '20%' }}
                    transition={{ duration: 0.8, delay: i * 0.2 }}
                  />
                </div>
              </div>
            ))}
          </div>
        );
      case 'chart':
        return (
          <div className="h-20 flex items-end justify-center space-x-1 px-6">
            {[60, 80, 45, 90, 70].map((height, i) => (
              <motion.div
                key={i}
                className="w-4 bg-purple-400 rounded-t"
                animate={isHovered ? { height: `${height}%` } : { height: '20%' }}
                transition={{ duration: 0.6, delay: i * 0.1 }}
              />
            ))}
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen px-6">
      <h2 className="text-white font-bold text-[clamp(2rem,6vw,3rem)] mb-6 text-center">
        Powerful Features
      </h2>
      <p className="text-gray-300 text-lg mb-12 text-center max-w-2xl">
        Experience the future of call center hiring and training with our AI-powered platform
      </p>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-6xl w-full">
        {features.map((feature) => (
          <motion.div
            key={feature.id}
            className="bg-gray-900/40 backdrop-blur-sm border border-gray-700 rounded-xl p-6 text-center cursor-pointer"
            whileHover={{ scale: 1.02 }}
            onMouseEnter={() => setHoveredFeature(feature.id)}
            onMouseLeave={() => setHoveredFeature(null)}
            onClick={() => openModal(
              <div className="text-center">
                <div className="mb-4">{feature.icon}</div>
                <h3 className="text-white font-semibold text-xl mb-3">{feature.title}</h3>
                <p className="text-gray-300 mb-4">{feature.description}</p>
                <div className="bg-gray-800 rounded-lg p-4 mb-4">
                  <div className="text-sm text-gray-400 mb-2">Interactive Demo:</div>
                  {renderAnimation(feature.animation, true)}
                </div>
                <button className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg transition-colors">
                  Try Full Demo
                </button>
              </div>
            )}
          >
            <div className="mb-4">{feature.icon}</div>
            <h3 className="text-white font-semibold text-xl mb-3">{feature.title}</h3>
            <div className="mb-4">
              {renderAnimation(feature.animation, hoveredFeature === feature.id)}
            </div>
            <p className="text-gray-400 text-sm mb-4">{feature.description}</p>
            <div className="text-blue-400 text-sm flex items-center justify-center">
              Try Demo <Play size={16} className="ml-2" />
            </div>
          </motion.div>
        ))}
      </div>

      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => openModal(<ContactForm />)}
        className="mt-12 bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-full text-lg font-semibold transition-colors"
      >
        Book a Demo
      </motion.button>
    </div>
  );
};

// Solutions Section
const SolutionsSection = () => {
  const { openModal } = useAppStore();
  const [selectedSide, setSelectedSide] = useState(null);

  return (
    <div className="flex items-center justify-center min-h-screen px-6">
      <div className="max-w-6xl w-full">
        <h2 className="text-white font-bold text-[clamp(2rem,6vw,3rem)] mb-12 text-center">
          Solutions for Every Role
        </h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <motion.div
            className="bg-gray-900/40 backdrop-blur-sm border border-gray-700 rounded-xl p-8 cursor-pointer relative overflow-hidden"
            whileHover={{ scale: 1.02 }}
            onMouseEnter={() => setSelectedSide('managers')}
            onMouseLeave={() => setSelectedSide(null)}
            onClick={() => openModal(
              <div>
                <h3 className="text-white font-semibold text-xl mb-4">For Call Center Managers</h3>
                <div className="space-y-4">
                  <div>
                    <h4 className="text-white font-medium mb-2">How big is your team?</h4>
                    <div className="space-y-2">
                      {['1-5 agents', '5-20 agents', '20+ agents'].map(size => (
                        <button key={size} className="block w-full text-left px-4 py-2 rounded bg-gray-800 hover:bg-gray-700 text-white transition-colors">
                          {size}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <h4 className="text-white font-medium mb-2">Would you like a pilot?</h4>
                    <div className="flex gap-3">
                      <button 
                        onClick={() => openModal(<ContactForm />)}
                        className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 rounded transition-colors"
                      >
                        Yes, book demo
                      </button>
                      <button 
                        onClick={() => alert('Added to waitlist!')}
                        className="flex-1 bg-gray-700 hover:bg-gray-600 text-white py-2 rounded transition-colors"
                      >
                        Not yet
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          >
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-transparent"
              animate={{ opacity: selectedSide === 'managers' ? 1 : 0 }}
            />
            <div className="relative z-10">
              <Target className="w-12 h-12 text-blue-400 mb-4" />
              <h3 className="text-white font-semibold text-2xl mb-4">For Managers</h3>
              <ul className="space-y-3 text-gray-300 mb-6">
                <li className="flex items-center">
                  <Check className="w-5 h-5 text-green-400 mr-3 flex-shrink-0" />
                  Automate voice interviews
                </li>
                <li className="flex items-center">
                  <Check className="w-5 h-5 text-green-400 mr-3 flex-shrink-0" />
                  Score candidates instantly
                </li>
                <li className="flex items-center">
                  <Check className="w-5 h-5 text-green-400 mr-3 flex-shrink-0" />
                  Reduce hiring time by 70%
                </li>
              </ul>
              <div className="text-blue-400 font-medium flex items-center">
                Schedule a Demo <ChevronRight size={16} className="ml-2" />
              </div>
            </div>
          </motion.div>

          <motion.div
            className="bg-gray-900/40 backdrop-blur-sm border border-gray-700 rounded-xl p-8 cursor-pointer relative overflow-hidden"
            whileHover={{ scale: 1.02 }}
            onMouseEnter={() => setSelectedSide('agents')}
            onMouseLeave={() => setSelectedSide(null)}
            onClick={() => openModal(
              <div>
                <h3 className="text-white font-semibold text-xl mb-4">For Call Center Agents</h3>
                <div className="space-y-4">
                  <div>
                    <h4 className="text-white font-medium mb-2">What's your experience level?</h4>
                    <div className="space-y-2">
                      {['New to call centers', '1-2 years experience', '2+ years experience'].map(level => (
                        <button key={level} className="block w-full text-left px-4 py-2 rounded bg-gray-800 hover:bg-gray-700 text-white transition-colors">
                          {level}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <h4 className="text-white font-medium mb-2">Ready to start training?</h4>
                    <div className="flex gap-3">
                      <button className="flex-1 bg-green-600 hover:bg-green-700 text-white py-2 rounded transition-colors">
                        Start Training
                      </button>
                      <button className="flex-1 bg-gray-700 hover:bg-gray-600 text-white py-2 rounded transition-colors">
                        Learn More
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          >
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-green-600/20 to-transparent"
              animate={{ opacity: selectedSide === 'agents' ? 1 : 0 }}
            />
            <div className="relative z-10">
              <Users className="w-12 h-12 text-green-400 mb-4" />
              <h3 className="text-white font-semibold text-2xl mb-4">For Agents</h3>
              <ul className="space-y-3 text-gray-300 mb-6">
                <li className="flex items-center">
                  <Check className="w-5 h-5 text-green-400 mr-3 flex-shrink-0" />
                  Train with real-life AI scenarios
                </li>
                <li className="flex items-center">
                  <Check className="w-5 h-5 text-green-400 mr-3 flex-shrink-0" />
                  Get skill feedback instantly
                </li>
                <li className="flex items-center">
                  <Check className="w-5 h-5 text-green-400 mr-3 flex-shrink-0" />
                  Unlock real interviews
                </li>
              </ul>
              <div className="text-green-400 font-medium flex items-center">
                Start Training Preview <ChevronRight size={16} className="ml-2" />
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

// Pricing Section
const PricingSection = () => {
  const { openModal } = useAppStore();

  const plans = [
    {
      name: "Starter",
      price: "Free",
      description: "Perfect for trying out our platform",
      features: [
        "Up to 10 interviews",
        "Basic training access",
        "Standard reports",
        "Email support"
      ],
      cta: "Try Free",
      popular: false
    },
    {
      name: "Pro Plan",
      price: "$50/month",
      description: "For growing call centers",
      features: [
        "Unlimited interviews",
        "Advanced analytics",
        "Priority support",
        "Custom training modules",
        "API access"
      ],
      cta: "Upgrade Now",
      popular: true
    }
  ];

  return (
    <div className="flex flex-col items-center justify-center min-h-screen px-6">
      <h2 className="text-white font-bold text-[clamp(2rem,6vw,3rem)] mb-6 text-center">
        Simple Pricing
      </h2>
      <p className="text-gray-300 text-lg mb-12 text-center max-w-2xl">
        Start free and upgrade as you grow
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl w-full">
        {plans.map((plan, index) => (
          <motion.div
            key={plan.name}
            className={`relative bg-gray-900/40 backdrop-blur-sm border rounded-xl p-8 text-center ${
              plan.popular ? 'border-blue-500' : 'border-gray-700'
            }`}
            whileHover={{ scale: 1.02 }}
          >
            {plan.popular && (
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                <span className="bg-blue-600 text-white px-4 py-1 rounded-full text-sm font-semibold">
                  Most Popular
                </span>
              </div>
            )}
            <h3 className="text-white font-semibold text-2xl mb-2">{plan.name}</h3>
            <div className="text-4xl font-bold mb-2">
              <span className="text-white">{plan.price}</span>
            </div>
            <p className="text-gray-400 mb-6">{plan.description}</p>
            <ul className="space-y-3 mb-8">
              {plan.features.map((feature) => (
                <li key={feature} className="flex items-center text-gray-300">
                  <Check className="w-5 h-5 text-green-400 mr-3 flex-shrink-0" />
                  {feature}
                </li>
              ))}
            </ul>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => {
                if (plan.name === "Starter") {
                  openModal(
                    <div className="text-center">
                      <h3 className="text-white font-semibold text-xl mb-4">Start Your Free Trial</h3>
                      <p className="text-gray-300 mb-6">Enter your email to get started with 10 free interviews</p>
                      <input
                        type="email"
                        placeholder="Enter your email"
                        className="w-full px-4 py-3 rounded-lg bg-gray-800 border border-gray-600 text-white focus:border-blue-400 outline-none mb-4"
                      />
                      <button className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg transition-colors">
                        Start Free Trial
                      </button>
                    </div>
                  );
                } else {
                  openModal(<ContactForm />);
                }
              }}
              className={`w-full py-3 rounded-lg font-semibold transition-colors ${
                plan.popular
                  ? 'bg-blue-600 hover:bg-blue-700 text-white'
                  : 'bg-gray-700 hover:bg-gray-600 text-white'
              }`}
            >
              {plan.cta}
            </motion.button>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

// Contact Section
const ContactSection = () => {
  const { openModal } = useAppStore();

  return (
    <div className="flex flex-col items-center justify-center min-h-screen px-6">
      <h2 className="text-white font-bold text-[clamp(2rem,6vw,3rem)] mb-6 text-center">
        Get In Touch
      </h2>
      <p className="text-gray-300 text-lg mb-12 text-center max-w-2xl">
        Ready to transform your call center? Let's discuss how we can help.
      </p>

      <div className="max-w-md w-full">
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => openModal(<ContactForm />)}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white py-4 rounded-lg font-semibold mb-6 transition-colors"
        >
          Schedule a Demo
        </motion.button>

        <div className="text-center">
          <p className="text-gray-400 mb-4">Or reach out directly:</p>
          <div className="space-y-2">
            <p className="text-gray-300">hello@callcenterai.com</p>
            <p className="text-gray-300">+1 (555) 123-4567</p>
          </div>
        </div>
      </div>
    </div>
  );
};

// Gradient Bars Background
const GradientBars = () => {
  const [numBars] = useState(15);

  const calculateHeight = (index, total) => {
    const position = index / (total - 1);
    const maxHeight = 100;
    const minHeight = 30;
    const center = 0.5;
    const distanceFromCenter = Math.abs(position - center);
    const heightPercentage = Math.pow(distanceFromCenter * 2, 1.2);
    return minHeight + (maxHeight - minHeight) * heightPercentage;
  };

  return (
    <div className="absolute inset-0 z-0 overflow-hidden">
      <div
        className="flex h-full"
        style={{
          width: '100%',
          transform: 'translateZ(0)',
          backfaceVisibility: 'hidden',
          WebkitFontSmoothing: 'antialiased',
        }}
      >
        {Array.from({ length: numBars }).map((_, index) => {
          const height = calculateHeight(index, numBars);
          return (
            <div
              key={index}
              style={{
                flex: '1 0 calc(100% / 15)',
                maxWidth: 'calc(100% / 15)',
                height: '100%',
                background: 'linear-gradient(to top, rgb(59, 130, 246), transparent)',
                transform: `scaleY(${height / 100})`,
                transformOrigin: 'bottom',
                transition: 'transform 0.5s ease-in-out',
                animation: 'pulseBar 2s ease-in-out infinite alternate',
                animationDelay: `${index * 0.1}s`,
                outline: '1px solid rgba(0, 0, 0, 0)',
                boxSizing: 'border-box',
              }}
            />
          );
        })}
      </div>
    </div>
  );
};

// Navigation Bar
const Navbar = () => {
  const { currentSection, setCurrentSection, openModal } = useAppStore();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'features', label: 'Features' },
    { id: 'solutions', label: 'Solutions' },
    { id: 'pricing', label: 'Pricing' },
    { id: 'contact', label: 'Contact' },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-transparent py-6 px-6 md:px-12">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center">
          <motion.div 
            className="flex items-center cursor-pointer"
            onClick={() => setCurrentSection('home')}
            whileHover={{ scale: 1.05 }}
          >
            <Phone className="w-6 h-6 text-blue-400 mr-2" />
            <span className="text-white font-bold text-xl tracking-tighter">
              CallCenter AI
            </span>
          </motion.div>
          
          <div className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <motion.button
                key={item.id}
                onClick={() => setCurrentSection(item.id)}
                className={`transition-colors duration-300 ${
                  currentSection === item.id 
                    ? 'text-white border-b border-blue-400' 
                    : 'text-gray-300 hover:text-white'
                }`}
                whileHover={{ scale: 1.05 }}
              >
                {item.label}
              </motion.button>
            ))}
            <motion.button
              onClick={() => openModal(<ContactForm />)}
              className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-full transition-all duration-300"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Get Started
            </motion.button>
          </div>

          <div className="md:hidden">
            <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="text-white">
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="md:hidden mt-4 bg-gray-900 bg-opacity-95 backdrop-blur-sm rounded-lg p-4"
            >
              <div className="flex flex-col space-y-4">
                {navItems.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      setCurrentSection(item.id);
                      setIsMenuOpen(false);
                    }}
                    className={`text-left py-2 transition-colors duration-300 ${
                      currentSection === item.id ? 'text-white' : 'text-gray-300 hover:text-white'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
                <button
                  onClick={() => {
                    openModal(<ContactForm />);
                    setIsMenuOpen(false);
                  }}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-full transition-all duration-300 w-full"
                >
                  Get Started
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </nav>
  );
};

// Main App Component
export default function CallCenterApp() {
  const { currentSection, isModalOpen, modalContent, closeModal } = useAppStore();

  const renderSection = () => {
    switch (currentSection) {
      case 'home':
        return <HomeSection />;
      case 'features':
        return <FeaturesSection />;
      case 'solutions':
        return <SolutionsSection />;
      case 'pricing':
        return <PricingSection />;
      case 'contact':
        return <ContactSection />;
      default:
        return <HomeSection />;
    }
  };

  return (
    <div className="min-h-screen">
      <section className="relative min-h-screen flex flex-col items-center px-6 sm:px-8 md:px-12 overflow-hidden">
        <div className="absolute inset-0 bg-gray-950"></div>
        <GradientBars />
        <Navbar />
        
        <AnimatePresence mode="wait">
          <motion.div
            key={currentSection}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="relative z-10 w-full flex items-center justify-center"
          >
            {renderSection()}
          </motion.div>
        </AnimatePresence>
        
        <AnimatePresence>
          {isModalOpen && (
            <Modal onClose={closeModal}>
              {modalContent}
            </Modal>
          )}
        </AnimatePresence>
      </section>

      <style jsx global>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        
        @keyframes pulseBar {
          0% { transform: scaleY(var(--initial-scale, 1)); }
          100% { transform: scaleY(calc(var(--initial-scale, 1) * 1.3)); }
        }
        
        body {
          font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
        }
      `}</style>
    </div>
  );
}